#get sample data
data = NULL
for (i in c(1:30)){
  a = sample(c(rep(0,35),floor(runif(10,1,8))))
  data = rbind(data,a)
}

#draw plots
library(RColorBrewer)
par(mar=c(3,3,1,3),las=2)
colors = c("#dadada",brewer.pal(7,"Set1"))
x.len=nrow(data)
y.len=ncol(data)
image(1:x.len,1:y.len, as.matrix(data),col = colors, breaks=seq(-0.5,7.5,1),
      axes = FALSE, ann=F)

#add lines
abline(h=seq(0.5,0.5+y.len),col='white',lwd=0.25)
abline(v=seq(0.5,0.5+x.len),col='white',lwd=0.25)
abline(v=15.5,col="black",lwd=1.5)
abline(h=c(10.5,20.5,35.5),col="black",lwd=1.5)

#get sample names
sample.labels = c(paste("A",sprintf("%02.0f",c(1:15)),sep=''),
                  paste("C",sprintf("%02.0f",c(1:15)),sep=''))

#add samplename on the bottom
mtext("Patient",cex=1,side = 1,las=1)
axis(side=1,at=1:x.len, labels = sample.labels, tick = FALSE, las=2)

#get genename
get.geneName <- function(n){
  genename = NULL
  for (i in c(1:n)){
    a = paste(c(sample(c(LETTERS,0:9))[1:sample(c(4:8))[1]]),collapse = '')
    genename = c(genename,a)
  }
  return(genename)
}
gene.names = get.geneName(45)
#add genename on the right
axis(side=4,at=1:y.len, labels=gene.names, tick=F, las=1, font=3,line=-0.9)

#add legend
legend(1,45,legend=c("NA","Missense","Nonsense","Stop Loss","Stop Gain","Frameshift Ins","Frameshift Del","Splicing"), fill=colors)

#text on the left
text(x=-2, y=0.5, labels="JAK-STAT3\nSignaling", pos=4,xpd=T, cex=0.8,srt = 90)
text(x=-2, y=12.5, labels="Cytokine", pos=4,xpd=T, cex=0.8, srt = 90)
text(x=-2, y=25.5, labels="Ras", pos=4, xpd=T, cex=0.8, srt=90)
text(x=-2, y=37.5, labels="MAPK", pos=4, xpd=T, cex=0.8, srt=90)

#add box
box()
