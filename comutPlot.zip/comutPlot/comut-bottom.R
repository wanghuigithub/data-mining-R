options(stringsAsFactors=F)
d1 <- read.table("snv.txt",header=T,sep="\t")

calfreq <- function(dat)
{
  tbl <- table(dat$Base.change,dat$Patient.ID)
  ATCG <- colSums(tbl[c("A>C","T>G"),])
  ATTA <- colSums(tbl[c("A>T","T>A"),])
  CGAT <- colSums(tbl[c("C>A","G>T"),])
  CGGC <- colSums(tbl[c("C>G","G>C"),])
  ATGC <- colSums(tbl[c("A>G","T>C"),])
  CGTA <- colSums(tbl[c("G>T","G>A"),])
  vv <- rbind(ATCG,ATTA,CGAT,CGGC,ATGC,CGTA)
  frq <- NULL
  for (i in 1:ncol(vv))
  {
    frq <- cbind(frq,vv[,i]/colSums(vv)[i])
  }
  colnames(frq) = colnames(tbl)
  return(frq)
}
#pdf("ACGT.pdf",height=6,width=4)
colors=c("#d63d4f","#f26c43","#faad60","#fce08b","#e4ea99","#acd7a4")

value <- calfreq(d1)
ltext <- c("A/T>C/G","A/T>T/A","C/G>A/T","C/G>G/C","A/T>G/C","C/G>T/A")
par(mar=c(4, 0, 1, 1))
barplot(as.matrix(value), col=colors, axes=T,legend.text = ltext, xaxs='i',space=0,
        las=3,args.legend = list( x="topright", bty = "n", inset=c(-0.45, 0)),border=NA)
legend("topright",fill=colors,ltext, box.col='grey')

