snv = ceiling(sort(runif(30) * 30,decreasing = T))
indel = ceiling(sort(runif(30) * 10,decreasing = T))
data = data.frame(snv,indel)
par(las=2)
barplot(as.matrix(t(data)),
        col=c("#4cb049","#307eb9"),
        xaxs='i',
        border = "white",
        space=0,
        ylim=c(0,40))


