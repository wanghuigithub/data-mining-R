## This script was designed to preprocess microarray 
## data of Aglient and generate expression values. 

##nomalization
library("marray")
target=read.table("target.txt",header=T)
RG <- read.maimages(target, source="agilent", path="./GSE107914/",green.only=TRUE)
y <- backgroundCorrect(RG,method="normexp")
y <- normalizeBetweenArrays(y,method="quantile")

##filtration
neg95 <- apply(y$E[y$genes$ControlType==-1,],2,function(x) quantile(x,p=0.95))
cutoff <- matrix(1.1*neg95,nrow(y),ncol(y),byrow=TRUE)
isexpr <- rowSums(y$E > cutoff) >= 2
y0 <- y[y$genes$ControlType==0 & isexpr,]
exp <- y0$E
rownames(exp) <- y0$genes$ProbeName
exp <- exp[!duplicated(rownames(exp)),]
fil <- is.na(rownames(exp)) | rownames(exp)==""
exp <- exp[!fil,]
exp <- exp[!duplicated(rownames(exp)),]

##output to file
outfn <- "Expdata1.txt"
write.table(exp,outfn,quote=F,sep="\t",row.names=T,col.names=T)

