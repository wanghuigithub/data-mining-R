library(limma)
#import expression data
datExpr = read.table("Expdata.txt",header=T,sep="\t")
View(head(datExpr))
#import phenotype data
pheno = read.table('target.txt',header=T,sep="\t")
View(pheno)

#model design
Group = factor(pheno$Treatment,levels=c('drug1','drug2','drug3'))
design = model.matrix(~0+Group)
colnames(design) <- c('drug1','drug2','drug3')
design

#linear model fitness
fit <- lmFit(datExpr, design)

#generate contrast matrix
contrast.matrix <- makeContrasts(drug1-drug2,
                                 drug1-drug3,
                                 drug2-drug3,
                                 levels=design)

#constrast model fit 
fit2 <- contrasts.fit(fit, contrast.matrix)

#bayes model 
fit2 <- eBayes(fit2)

#get DEGs
diff = topTable(fit2,adjust.method="fdr",coef=1,p.value=0.05,
                lfc=log(2,2),number=5000,sort.by = 'logFC')
View(diff)

#import Annotaion
anno = read.csv("Annotation.csv",head=T)
View(head(anno))

#add annotations to DEGs
diff$Gene = anno$GeneSymbol[match(rownames(diff),anno$ProbeName)]
diff$ID_REF = rownames(diff)
diff = diff[,c(8,7,1:6)]
diff = diff[diff$Gene != '---',]
View(diff)
#output
write.table(diff,'DEG.txt',col.names=T,row.names=F,sep="\t",quote=F)

