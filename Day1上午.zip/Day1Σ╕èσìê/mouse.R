dat <- read.table("mouse.txt",header=T)
boxplot(day~strain,dat,col="red")
