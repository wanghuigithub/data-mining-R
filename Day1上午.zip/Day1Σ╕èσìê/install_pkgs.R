pkgs1 = c("rgeos","rgdal","gplots", "ggplot2", "scatterplot3d", 
         "HGNChelper", "httr", "RCurl", "Hmisc",
         "rjson", "stringr", "survival",
         "VennDiagram","rgl","RColorBrewer",
         "maptools","rworldmap","maps","mapdata","qqman")
install.packages(pkgs1)


pkgs2 = c("limma","affy","annaffy","org.Hs.eg.db",
          "hgu133plus2.db","hgu133plus2cdf","clusterProfiler",
          "beadarray","GEOquery","illuminaHumanv1.db",
          "illuminaHumanv2.db","illuminaHumanv3.db",
          "illuminaHumanv4.db","BeadArrayUseCases",
          "GOstats","GenomicRanges","Biostrings","marray")
source("http://www.bioconductor.org/biocLite.R")
biocLite(pkgs2)

