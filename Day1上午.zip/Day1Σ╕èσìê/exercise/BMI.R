dat <-  read.table('BMI.txt',header=T)

bmi = dat$weight / (dat$height ^ 2)

t.test(bmi,mu=22.5)$p.value

