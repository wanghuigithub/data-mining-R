library(limma)

#read in raw data
maqc <- read.ilmn(files="GSE43795_non_normalized.txt",
                  expr="Sample",probeid="ID_REF",
                  other.columns = "Detection Pval"
                  )

#background correction and quantile normalization
maqc.norm <- neqc(maqc,detection.p = "Detection Pval")

#get expression data
expdata <- maqc.norm$E

##PCA
pca=princomp(expdata)
plot(pca$loadings[,c(1:2)])


boxplot(log2(maqc$E),range=0,las=2,
        xlab="",ylab=expression(log[2](intensity)),
        main="Raw intensity")
boxplot(expdata, range=0, las=2,
        xlab="",ylab=expression(log[2](intensity)),
        main="Normalized expression")

#batch effects investigation
plotMDS(expdata)

#output expressiond data
write.table(expdata,"Expdata.txt",col.names = T,row.names = T,quote=F,sep="\t")

