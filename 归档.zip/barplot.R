# read in data 
data = read.table("barplot.txt",header=T)

# draw barplots with different arguments
barplot(data[,2])
barplot(data[,2],names.arg = data[,1])
barplot(data[,2],names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value")
barplot(data[,2],names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value",col="blue")
barplot(data[,2],names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value",col=c("grey","red","blue","orange","green"))


# draw stack barplot
data2 = t(data[,c(2,3)])
barplot(as.matrix(data2))
barplot(as.matrix(data2),
        names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value",
        col=c("blue","red"),
        legend=c("Low Dose","High Dose"),
        ylim=c(0,50))

box() 

# draw non-stack barplot
barplot(as.matrix(data2),
        names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value",
        col=c("blue","red"),
        legend=c("Low Dose","High Dose"),
        ylim=c(0,30),
        beside=TRUE)
box() 

# draw horizonal barplot
barplot(as.matrix(data2),
        names.arg = data[,1],main="Fig2", xlab="Drug", ylab="Value",
        col=c("blue","red"),
        legend=c("Low Dose","High Dose"),
        xlim=c(0,50),
        horiz=TRUE,
        space=0.5,
        las=2,
        cex.axis = 0.5,
        cex.names = 0.7)

box() 

# draw barplots with ggplot2 with different arguments
# first transform the data 
library(reshape2)
data3 = melt(data,id.var='Group')

library(ggplot2)
ggplot(data3,aes(x=Group,y=value,Group=variable,color=variable,fill=variable))+
  geom_bar(stat="identity",position="stack")

ggplot(data3,aes(x=Group,y=value,Group=variable,color=variable,fill=variable))+
  geom_bar(stat="identity",position="dodge",width=0.8)+
  ylab("Counts")

ggplot(data3,aes(x=Group,y=value,Group=variable,color=variable,fill=variable))+
  geom_bar(stat="identity",position="fill",width=0.8)+
  ylab("Counts")+
  coord_flip()
