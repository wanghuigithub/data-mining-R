###########################################
##
## Author: Wang xx
## Email : xxxx@sjtu.edu.cn
## Date  : 2018-04-14
## Usage : Exercise 1 (Scatter plot)
##
###########################################

data = read.table("exercise1.txt",sep="\t",header = T)

data.group1 = data[data$group == 'G1',]
data.group2 = data[data$group == 'G2',]
data.group3 = data[data$group == 'G3',]

## solution 1
par(mfrow=c(1,3))
plot(data.group1$gene1,data.group1$gene2,pch=16,
     xlab='Gene1',ylab='Gene2',main='G1',
     xlim=c(0,6),ylim=c(0,2))
plot(data.group2$gene1,data.group2$gene2,pch=16,
     xlab='Gene1',ylab='Gene2',main='G2',
     xlim=c(0,6),ylim=c(0,2))
plot(data.group3$gene1,data.group3$gene2,pch=16,
     xlab='Gene1',ylab='Gene2',main='G3',
     xlim=c(0,6),ylim=c(0,2))

## solution 2
par(mfrow=c(1,1))
point.col = c(rep("green",15),
              rep("red",15),
              rep("blue",15))
point.pch = c(rep(1,15),rep(2,15),rep(16,15))
plot(data$gene1,data$gene2,pch=point.pch,col=point.col,
     xlab='Gene1',ylab='Gene2',
     xlim=c(0,6),ylim=c(0,2))

## solution3
library(ggplot2)
ggplot(data,aes(gene1,gene2,color=group,shape=group))+
  geom_point(size=2)
