data0 = read.table("heatmap.txt", header=T)
data = data0[,-1]
rownames(data) = data0[,1]

library(gplots)
heatmap.2(as.matrix(data))

library(RColorBrewer)
color = c(rep("orange",3),rep("blue",3))
heatmap.2(as.matrix(data),col = greenred(75), 
          scale = "row",dendrogram = 'both',
          key = TRUE, symkey = FALSE, density.info = "none", 
          trace = "none", cexRow = 0.5,
          main = "Heatmap",
          ColSideColors = as.character(color)  
          ) 


