x <- seq(-10,10)
y <- x ^ 2
plot(x, y, main="Fig1", xlab="x axis", ylab="y axis", type="b")
abline(h=seq(0,100,10),col="grey")
abline(v=seq(-10,10,1),col="grey")


