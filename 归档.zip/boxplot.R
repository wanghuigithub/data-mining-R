dat <- read.table("boxplot.txt",header=T)
boxplot(Value~Group,data = dat)

#����
boxplot(Value~Group,data = dat,
        varwidth=TRUE,
        col="#6DC9F2",
        outline=FALSE,
        names=c("Control","Drug1","Drug2"),
        horizontal=FALSE )
#�߼�����
points(jitter(as.numeric(dat$Group)),dat$Value, pch = 16, col = "red")
