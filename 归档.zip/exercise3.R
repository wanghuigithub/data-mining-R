# read in data 
diff0 = read.table("volcano_plot.txt",sep="\t",header=T)

# draw scatterplot
plot(diff0$logFC, -log10(diff0$adj.P.Val), pch=16, col="grey", cex=0.5,
     xlab = "log(FC)", ylab = "-log10(P value)", main="Volcano plot")

# add cutoff lines
abline(v=c(-1,1), h=-log10(0.01), col="red")

