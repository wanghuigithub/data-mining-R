# read in data
dat0=read.table("3d_scatter_plot.txt",header=TRUE,sep="\t")

# check and deal with raw data 
head(dat0)
dat1 = dat0[,-1]
rownames(dat1) = dat0[,1]

# defind the color of samples
color = c(rep('red',3),rep('orange',3),rep('blue',3))
color


# draw 3d plot with scatterplot3d package
library(scatterplot3d)

# define the output pdf file
pdf("scatter3d.pdf",width = 8,height = 8,onefile = T)
for (ang in seq(-360,360,10)){
  scatterplot3d(dat1,main='3D plot',color=color,type='p',
                highlight.3d=F,angle=ang,grid=T,box=T,scale.y=1,
                cex.symbols=1.2,pch=16,col.grid='lightblue')
  legend("topright",c('Control','Drug','Surgery'),fill=c('red','orange','blue'),box.col="grey")
}
dev.off()
