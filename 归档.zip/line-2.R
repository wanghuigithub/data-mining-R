x <- seq(-10,10)
y <- x ^ 2

plot(x, y, type="n", xlab="", ylab="", axes=F) 
lines(x,y) 
axis(1)
axis(at=seq(0,100,10), side=2) 
box() 
title(main="Fig1", xlab="x axis", ylab="y axis")
abline(h=seq(0,100,10),col="grey")
abline(v=seq(-10,10,1),col="grey")

points(x,y)
