x <- seq(-10,10)
y <- x ^ 2

plot(x, y, type="n", xlab="", ylab="", axes=F) 
lines(x,y) 
axis(1) 
axis(at=seq(0,100,10), side=2)
box() 
title(main="Fig1", xlab="x axis", ylab="y axis")
abline(h=seq(0,100,10),col="grey")
abline(v=seq(-10,10,1),col="grey")

points(x,y,col="red",pch=16)
library(RColorBrewer)
color <- brewer.pal(10,'Spectral')
points(x,y,col=color,pch=16,cex=1.5)

library(gplots)
color <- colorpanel(20,low="red", mid="green", high="red")
points(x,y,col=color,pch=16,cex=1.5)
